<?php
namespace Drupal\tag_custom\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Form\ConfirmFormBase;
use Drupal\file\Entity\File;

class ProductsFilterForm extends FormBase {
  public function getFormId(){
		return 'products_filter_form';
	}

  /**
  * Implemenation of hook_form()
  * 
  */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $activeTheme = \Drupal::theme()->getActiveTheme();
  
    // Get the theme name.
    $theme = $activeTheme->getName();

    // Get current url
     $current_path = \Drupal::service('path.current')->getPath();
     $current_path_alias = \Drupal::service('path_alias.manager')->getAliasByPath($current_path);
     $host = explode('/', $current_path_alias);


  if ($host[0] != 'ads') {
    //Get Product Count under the All Upholstery Category
    $query1 = \Drupal::database()->select('node_field_data', 'nfd');
    //$query1->join('field_data_field_product_category', 'f', 'n.nid = f.entity_id');
    $query1->fields('nfd', array('nid'));
    $query1->condition('nfd.type', 'product');
    $query1->condition('nfd.status', 1);
    $count = $query1->countQuery()->execute()->fetchField();

    //Get Product Texture Items
    $query_tex = \Drupal::database()->select('taxonomy_term_field_data', 'tfd');
    $query_tex->fields('tfd', array('tid', 'vid', 'name'));
    $query_tex->condition('tfd.vid', 'product_texture', '=');
    $query_tex->orderBy('tfd.weight', 'ASC');
    $pro_texture = $query_tex->execute();

    //Get Product Application Items
    $query_app = \Drupal::database()->select('taxonomy_term_field_data', 'tfd');
    $query_app->fields('tfd', array('tid', 'vid', 'name'));
    $query_app->condition('tfd.vid', 'product_application', '=');
    $query_app->orderBy('tfd.weight', 'ASC');
    $pro_application = $query_app->execute();
        
    //Get Product Tag List Performance Items
    $per_query = \Drupal::database()->select('taxonomy_term_field_data', 'tfd');
    //$per_query->join('field_data_field_term_weight_in_filter', 'tf', 'tf.entity_id = t.tid');
    //$per_query->join('field_data_field_enable_performance', 'ep', 'ep.entity_id = t.tid');
    $per_query->fields('tfd', array('tid', 'vid', 'name'));
    $per_query->condition('tfd.vid', 'product_tags', '=');
   // $per_query->condition('ep.field_enable_performance_value', 1, '=');
    //$per_query->orderBy('tf.field_term_weight_in_filter_value', 'ASC');
    $per_query->orderBy('tfd.weight', 'ASC');
    $per_result = $per_query->execute();

    //Get Product Tag List Finish Items
    $query = \Drupal::database()->select('taxonomy_term_field_data', 'tfd');
    //$query->join('field_data_field_term_weight_in_filter', 'tf', 'tf.entity_id = t.tid');
   // $query->join('field_data_field_enable_performance', 'ep', 'ep.entity_id = t.tid');
    $query->fields('tfd', array('tid', 'vid', 'name'));
    $query->condition('tfd.vid', 'product_tags', '=');
    //$query->condition('ep.field_enable_performance_value', 0, '=');
    //$query->orderBy('tf.field_term_weight_in_filter_value', 'ASC');
    $query->orderBy('tfd.weight', 'ASC');
    $result = $query->execute();

    $q = \Drupal::database()->select('taxonomy_term_field_data', 'tfd');
    $q->fields('tfd', array('tid', 'vid', 'name'));
    $q->condition('tfd.vid', 'product_type', '=');
    $q->orderBy('tfd.name', 'ASC');
    $res = $q->execute();

    //Get Floors and Walls List Items
    $qfloor = \Drupal::database()->select('taxonomy_term_field_data', 'tfd');
    $qfloor->fields('tfd', array('tid', 'vid', 'name'));
    $qfloor->condition('tfd.vid', 'floor_and_walls', '=');
    $qfloor->orderBy('tfd.name', 'ASC');
    $resfloor = $qfloor->execute();

    $per_options = array();
    $options = array();
    $optionsType = array();
    $optionsfloor = array();

    while ($texture = $pro_texture->fetchAssoc()) {
      $texture_options[$texture['tid']] = $texture['name'];
    }

    while ($application = $pro_application->fetchAssoc()) {
      $application_options[$application['tid']] = $application['name'];
    }

    while ($prs = $per_result->fetchAssoc()) {
      $per_options[$prs['tid']] = $prs['name'];
    }

    //$options['-1'] = t('All Characteristics (reset)');
    while ($rs = $result->fetchAssoc()) {
      $options[$rs['tid']] = $rs['name'];
    }

    //$optionsType['-1'] = t('All Types (reset)');
    while ($re = $res->fetchAssoc()) {
      $optionsType[$re['tid']] = $re['name'];
    }

    while ($rf = $resfloor->fetchAssoc()) {
      $optionsfloor[$rf['tid']] = $rf['name'];
    }

    $form['performance_tags'] = array(
      '#type' => 'checkboxes',
      '#options' => $per_options,
      '#title' => t('Performance'),
    );
    $form['product_texture'] = array(
      '#type' => 'checkboxes',
      '#options' => $texture_options,
      '#title' => t('Texture'),
    );
    $form['product_application'] = array(
      '#type' => 'checkboxes',
      '#options' => $application_options,
      '#title' => t('Application'),
    );
    $form['product_tags'] = array(
      '#type' => 'checkboxes',
      '#options' => $options,
      '#title' => t('Types'),
    );
    $form['product_type'] = array(
      '#type' => 'checkboxes',
      '#options' => $optionsType,
      '#title' => t('Characteristics'),
    );
    $form['floor_and_walls'] = array(
      '#type' => 'checkboxes',
      '#options' => $optionsfloor,
      '#title' => t('Type'),
    );

    //Get Product Industry Use List Items
    $query3 = \Drupal::database()->select('taxonomy_term_field_data', 'tfd');
    $query3->fields('tfd', array('tid', 'vid', 'name'));
    $query3->condition('tfd.vid', 'industry_use', '=');
    $query3->orderBy('tfd.weight', 'ASC');
    $result3 = $query3->execute();

    $industry_use_options = array();
    while ($rs3 = $result3->fetchAssoc()) {
      if ($rs3['name'] != 'Motorcoach') {
        $industry_use_options[$rs3['tid']] = $rs3['name'];
      }
    }

    $form['industry_use'] = array(
      '#type' => 'checkboxes',
      '#options' => $industry_use_options,
      //'#title' => t('By Use'),
      '#title' => t('By Market'),
    );

    if ($theme == 'edelmanleather'):
      if (isset($host[3]) && $host[3] == 'tile-color'):
        $split_array = explode('&', $host[3]);
        //echo "<pre>";print_r($split_array);die;
        $color_id_val = explode('color_tid=', $split_array[4]);
        //echo "<pre>";print_r($color_id_val);die;
        //$color_id_val = '';
        //Get Product Color List Items
        $query2 = \Drupal::database()->select('taxonomy_term_field_data', 'tfd');
        $query2->fields('tfd', array('tid', 'vid', 'name'));    
        $query2->condition('tfd.vid', 'tile_colorway', '=');    
        $query2->orderBy('tfd.weight', 'ASC');  

        $result2 = $query2->execute();
        if ($color_id_val[1] != 0) {
          $select_class = 'selected';
          $all_class = '';
        }
        else {
          $select_class = '';
          $all_class = 'active';
        }
        $color_product = '<ul class="' . $select_class . '">';
        $color_product .= '<li class="' . $all_class . '"><a href="#" rel="0" title="All">All</a></li>';
        while ($rs2 = $result2->fetchAssoc()) {
          $color_load = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($rs2['tid']);
          if ($color_load->field_color_code_value['0']->value != ''):
            $color_code_val = $color_load->field_color_code_value['0']->value;
          endif;
          if ($color_id_val[1] == $rs2['tid']):
            $color_class = 'active';
          else:
            $color_class = '';
          endif;
          $color_product .= '<li class="' . $color_class . '">
                                  <a href="#" rel="' . $rs2['tid'] . '" title="' . $rs2['name'] . '" style="background: ' . $color_code_val . ';"></a>
                              </li>';
        }
        $color_product .= '</ul>';
      else:
        $split_array = explode('&', $host[3]);
        //$color_id_val = explode('color_tid=', $split_array[6]);
        $color_id_val = [];
        $color_id_val[1] = 0;
        //Get Product Color List Items
        $query2 = \Drupal::database()->select('taxonomy_term_field_data', 'tfd'); 
        $query2->fields('tfd', array('tid', 'vid', 'name'));    
        $query2->condition('tfd.vid', 'product_colorways', '=');    
        $query2->orderBy('tfd.weight', 'ASC');  

        $result2 = $query2->execute();
        if ($color_id_val[1] != 0) {
          $select_class = 'selected';
          $all_class = '';
        }
        else {
          $select_class = '';
          $all_class = 'active';
        }
        $color_product = '<ul class="' . $select_class . '">';
        $color_product .= '<li class="' . $all_class . '"><a href="#" rel="0" title="All">All</a></li>';
        while ($rs2 = $result2->fetchAssoc()) {
          $color_load = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($rs2['tid']);
          $image_desc = $color_load->description->value;
          $imageuri = file::load($color_load->field_color_images[0]->target_id);//get original image path
          $imageurl = file_create_url($imageuri->getFileUri());
          if ($color_load->field_color_code_value[0]->value != ''):
            $color_code_val = $color_load->field_color_code_value[0]->value;
          endif;
          if ($color_id_val[1] == $rs2['tid']):
            $color_class = 'active';
          else:
            $color_class = '';
          endif;
          $color_product .= '<li class="' . $color_class . '">
                                  <a href="#" rel="' . $rs2['tid'] . '" title="' . $rs2['name'] . '" style="background: ' . $color_code_val . ';"></a>
                              </li>';
        }
        $color_product .= '</ul>';
      endif;
      //echo "<pre>";print_r($color_product);die;
    else:
      //Get Product Color List Items
      $query2 = \Drupal::database()->select('taxonomy_term_field_data', 'tfd'); 
      $query2->fields('tfd', array('tid', 'vid', 'name'));
      $query2->condition('tfd.vid', 'product_colorways', '=');
      $query2->orderBy('tfd.weight', 'ASC');
      $result2 = $query2->execute();

      $color_product = '';
      while ($rs2 = $result2->fetchAssoc()) {
        $color_load = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($rs2['tid']);
        $image_desc = $color_load->description->value;
        $imageuri = file::load($color_load->field_color_images[0]->target_id);//get original image path
        $imageurl = file_create_url($imageuri->getFileUri());
        
        $color_product .= '<div class="color-product">
                                <a href="#" rel="' . $rs2['tid'] . '" title="' . $rs2['name'] . '">
                                  <div class="color-box"><img data-desc = "' . $image_desc . '" src="' . $imageurl . '"/></div>
                                </a>
                            </div>';
      }
    endif;
    $form['product_colors'] = array(
      '#markup' => $color_product,
    );
    $form['product_colors_tid'] = array('#type' => 'hidden', '#value' => '', '#attributes' => array('id' => 'product_colors_tid'));
  }
  else {
    //Get Product Tag List Items
    $query = \Drupal::database()->select('taxonomy_term_field_data', 'tfd'); 
    $query->fields('tfd', array('tid', 'vid', 'name'));
    $query->condition('tfd.vid', 'ads_status', '=');
    $result = $query->execute();

    $options = array();
    while ($rs = $result->fetchAssoc()) {
      $options[$rs['tid']] = $rs['name'];
    }

    $form['ads_status'] = array(
      '#type' => 'checkboxes',
      '#options' => $options,
      '#title' => t('Status'),
    );
  }
  return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
  
    }
}
