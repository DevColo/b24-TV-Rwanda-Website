<?php
namespace Drupal\tag_custom\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Form\ConfirmFormBase;

class ProductsSortByForm extends FormBase {
  public function getFormId(){
		return 'products_sort_by_form';
	}

  /**
  * Implemenation of hook_form()
  * 
  */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Get current url
     $current_path = \Drupal::service('path.current')->getPath();
     $current_path_alias = \Drupal::service('path_alias.manager')->getAliasByPath($current_path);
     $host = explode('/', $current_path_alias);

    if (($host[0] == 'products' && $host[1] == 'upholstery-leather' && $host[2] == '') || ($host[1] == 'aviation') || ($host[0] == 'ads')) {
      $view_by_options = array('6' => '6', '12' => '12', '24' => '24', '36' => '36', '10000' => 'All');
    }
    else {
      $view_by_options = array('8' => '8', '16' => '16', '24' => '24', '36' => '36', '10000' => 'All');
    }
    if (($host[0] != 'ads')) {
      if (isset($host[2]) && $host[2] == "cow-rugs") {
        $form['product_sort_by'] = array(
          '#type' => 'select',
          '#title' => t('Sort by'),
          '#options' => array(
            'default' => t('Default'),
            'asc' => t('A – Z'),
            'desc' => t('Z – A'),
          ),
        );
      }
      else {
        $form['product_sort_by'] = array(
          '#type' => 'select',
          '#title' => t('Sort by'),
          '#options' => array(
            'asc' => t('A – Z'),
            'desc' => t('Z – A'),
          ),
        );
      }
    }
    else {
      $form['product_sort_by'] = array(
        '#type' => 'select',
        '#title' => t('Sort by'),
        '#options' => array(
          'new' => t('Newest'),
          'old' => t('Oldest'),
          'asc' => t('A – Z'),
          'desc' => t('Z – A'),
        ),
      );
    }
    // $form['pager'] = array(
    //   '#theme' => 'pager',
    // );
    $form['#theme'] = 'products_sort_by_form';
    $form['product_view_by'] = array(
      '#type' => 'select',
      '#title' => t('View'),
      '#options' => $view_by_options,
    );

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
  
    }
}
