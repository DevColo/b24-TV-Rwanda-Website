<?php

/**
 * @file
 * Post-update functions for the Admin Toolbar Tools module.
 */

/**
 * Update container for admin_toolbar_tools.helper arguments.
 */
function admin_toolbar_tools_post_update_helper_added_config_factory() {
  // Intentionally empty to trigger a service container rebuild.
}
